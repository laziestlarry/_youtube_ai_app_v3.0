from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import models
from app.db.session import SessionLocal
from app.schemas.assessment import AssessmentCreate, AssessmentOut, AnswerCreate
from app.services.scoring import compute_scores_for_assessment


router = APIRouter(prefix="/assessments", tags=["assessments"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=AssessmentOut)
def create_assessment(payload: AssessmentCreate, db: Session = Depends(get_db)):
    organization = (
        db.query(models.Organization)
        .filter(models.Organization.name == payload.organization_name)
        .first()
    )
    if not organization:
        organization = models.Organization(name=payload.organization_name)
        db.add(organization)
        db.commit()
        db.refresh(organization)

    assessment = models.Assessment(
        organization_id=organization.id,
        status="in_progress",
    )
    db.add(assessment)
    db.commit()
    db.refresh(assessment)

    return AssessmentOut(
        id=assessment.id,
        organization_name=organization.name,
        status=assessment.status,
        overall_score=assessment.overall_score,
        readiness_level=assessment.readiness_level,
        dimension_scores=[],
    )


@router.post("/{assessment_id}/answers")
def submit_answers(
    assessment_id: int, answers: List[AnswerCreate], db: Session = Depends(get_db)
):
    assessment = (
        db.query(models.Assessment)
        .filter(models.Assessment.id == assessment_id)
        .first()
    )
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    for payload in answers:
        question = (
            db.query(models.Question)
            .filter(models.Question.id == payload.question_id)
            .first()
        )
        if not question:
            continue

        answer = models.Answer(
            assessment_id=assessment_id,
            question_id=payload.question_id,
            numeric_value=payload.numeric_value,
            raw_value=payload.raw_value,
        )
        db.add(answer)
    db.commit()

    return {"status": "answers_saved"}


@router.post("/{assessment_id}/submit", response_model=AssessmentOut)
def complete_assessment(assessment_id: int, db: Session = Depends(get_db)):
    assessment = compute_scores_for_assessment(db, assessment_id)
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    dimension_scores = [
        {
            "dimension_id": score.dimension_id,
            "dimension_code": score.dimension.code,
            "dimension_name": score.dimension.name,
            "score": score.score,
            "level": score.level,
        }
        for score in assessment.dimension_scores
    ]

    return AssessmentOut(
        id=assessment.id,
        organization_name=assessment.organization.name,
        status=assessment.status,
        overall_score=assessment.overall_score,
        readiness_level=assessment.readiness_level,
        dimension_scores=dimension_scores,
    )


@router.get("/{assessment_id}", response_model=AssessmentOut)
def get_assessment(assessment_id: int, db: Session = Depends(get_db)):
    assessment = (
        db.query(models.Assessment)
        .filter(models.Assessment.id == assessment_id)
        .first()
    )
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    dimension_scores = [
        {
            "dimension_id": score.dimension_id,
            "dimension_code": score.dimension.code,
            "dimension_name": score.dimension.name,
            "score": score.score,
            "level": score.level,
        }
        for score in assessment.dimension_scores
    ]

    return AssessmentOut(
        id=assessment.id,
        organization_name=assessment.organization.name,
        status=assessment.status,
        overall_score=assessment.overall_score,
        readiness_level=assessment.readiness_level,
        dimension_scores=dimension_scores,
    )
