const LegalPage = () => {
  return (
    <div className="legal">
      <h2>Legal</h2>
      <p>Placeholder for Terms of Use, Privacy Policy, and AI/Data notice.</p>
      <p>
        Update this page with your formal documents before launching to
        customers.
      </p>
    </div>
  );
};

export default LegalPage;
