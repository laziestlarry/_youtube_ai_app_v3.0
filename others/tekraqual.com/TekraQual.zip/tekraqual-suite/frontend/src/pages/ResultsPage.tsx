import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import { api } from "../api/client";

type DimensionScore = {
  dimension_id: number;
  dimension_code: string;
  dimension_name: string;
  score: number;
  level: string;
};

type AssessmentResult = {
  id: number;
  organization_name: string;
  status: string;
  overall_score: number;
  readiness_level: string;
  dimension_scores: DimensionScore[];
};

const ResultsPage = () => {
  const { assessmentId } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState<AssessmentResult | null>(null);
  const [loading, setLoading] = useState(true);

  const bandInfo = (score: number) => {
    if (score < 50) return { label: "Foundation", color: "#d9534f" };
    if (score < 65) return { label: "Bronze", color: "#f0ad4e" };
    if (score < 80) return { label: "Silver", color: "#5bc0de" };
    return { label: "Gold", color: "#5cb85c" };
  };

  useEffect(() => {
    const load = async () => {
      try {
        const res = await api.get(`/assessments/${assessmentId}`);
        setData(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    if (assessmentId) {
      load();
    }
  }, [assessmentId]);

  if (loading) return <p style={{ padding: 16 }}>Loading results...</p>;
  if (!data) return <p style={{ padding: 16 }}>Results not found.</p>;

  const band = bandInfo(data.overall_score);
  const clampedScore = Math.min(Math.max(data.overall_score, 0), 100);
  const bands = [
    { label: "Foundation", min: 0, max: 49.99, color: "#fcebea" },
    { label: "Bronze", min: 50, max: 64.99, color: "#fff4e5" },
    { label: "Silver", min: 65, max: 79.99, color: "#eef7fd" },
    { label: "Gold", min: 80, max: 100, color: "#eff8ea" },
  ];
  const currentBand = bands.find(
    (b) => clampedScore >= b.min && clampedScore <= b.max
  );
  const nextBand = bands.find((b) => b.min > clampedScore);
  const gapToNext = nextBand ? Math.max(0, nextBand.min - clampedScore) : null;

  return (
    <div className="results" style={{ maxWidth: 720, margin: "0 auto", padding: 24 }}>
      <h2>TekraQual Readiness Summary</h2>
      <div
        style={{
          border: "1px solid #ddd",
          borderRadius: 10,
          padding: 16,
          marginTop: 12,
          background: "#f9fbff",
        }}
      >
        <p style={{ margin: "4px 0" }}>
          <strong>Organization:</strong> {data.organization_name}
        </p>
        <p style={{ margin: "4px 0" }}>
          <strong>Overall score:</strong> {Math.round(data.overall_score)} / 100
        </p>
        <p style={{ margin: "4px 0" }}>
          <strong>Readiness level:</strong> {data.readiness_level}
        </p>

        <div style={{ marginTop: 12 }}>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            {bands.map((b) => {
              const active = currentBand && currentBand.label === b.label;
              return (
                <div
                  key={b.label}
                  style={{
                    background: b.color,
                    padding: "10px 12px",
                    borderRadius: 8,
                    border: active ? "2px solid #0b8efb" : "1px solid #ddd",
                    minWidth: 120,
                  }}
                >
                  <div style={{ fontWeight: 700 }}>{b.label}</div>
                  <div style={{ fontSize: 12 }}>Range: {b.min}-{Math.floor(b.max)}</div>
                  {active && (
                    <div style={{ marginTop: 6, fontSize: 12, color: "#0b4e8f" }}>
                      You’re here: {Math.round(clampedScore)}/100
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          <p style={{ fontSize: 12, color: "#666", marginTop: 8 }}>
            {gapToNext !== null
              ? `Silver starts at 65; Gold at 80. You need +${Math.ceil(gapToNext)} points to reach ${nextBand?.label}.`
              : "You’re at the top band. Keep refining and monitoring."}
          </p>
        </div>
      </div>

      <h3 style={{ marginTop: 16 }}>Dimension breakdown</h3>
      <ul style={{ paddingLeft: 18 }}>
        {data.dimension_scores.map((score) => {
          const iconMap: Record<string, string> = {
            OPS: "📑",
            CX: "🤝",
            DATA: "📊",
            GOV: "🛡️",
            INCOME: "💰",
          };
          const icon = iconMap[score.dimension_code] || "";
          return (
            <li key={score.dimension_id} style={{ marginBottom: 6, display: "flex", gap: 6, alignItems: "center" }}>
              <span>{icon}</span>
              <span>
                <strong>{score.dimension_name}</strong> ({score.dimension_code}): {Math.round(score.score)} / 100 — Level {score.level}
              </span>
            </li>
          );
        })}
      </ul>

      <div
        style={{
          border: "1px solid #eee",
          borderRadius: 10,
          padding: 16,
          marginTop: 12,
          background: "#fffaf2",
        }}
      >
        <h4 style={{ marginTop: 0 }}>What to do next</h4>
        <ul style={{ paddingLeft: 18, margin: 0 }}>
          <li>Save this summary and share with your team.</li>
          <li>Book an implementation call to turn gaps into a plan.</li>
          <li>Re-run the scan after changes to track improvement.</li>
          <li>
            Track progress: a Silver-grade (65–79) means solid foundations; keep
            pushing toward Gold by closing the lowest dimension.
          </li>
        </ul>
      </div>

      <div className="results-actions" style={{ display: "flex", gap: 10, marginTop: 16 }}>
        <button onClick={() => navigate("/services")}>Turn This into an Implementation Plan</button>
        <button onClick={() => navigate("/")}>Back to Home</button>
      </div>
    </div>
  );
};

export default ResultsPage;
