# AutonomaX Creator Kit v1

**Drop your media files here and ship today.**

- Place `final_video.mp4` into: `Fiverr_Starter_Kit/Delivery/demo/`
- Place 3–10 audio files into: `Fiverr_Starter_Kit/Delivery/audio_beds/`
- Optional extras into: `Shopify_Creator_Kit/Product_Files/`
- Then zip `Shopify_Creator_Kit/Product_Files` as your Shopify digital download and attach to the product created by `shopify_product.csv`.

See `Quick_Deploy_Guide.pdf` for step-by-step.
