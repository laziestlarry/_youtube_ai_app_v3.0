"""init"""

revision = '3777f9183f41'
down_revision = '80cb70776baf'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
