const ContactPage = () => {
  return (
    <div className="contact">
      <h2>Contact</h2>
      <p>Book a call or send a note to discuss your readiness scan.</p>
      <ul>
        <li>Email: hello@tekraqual.com</li>
        <li>Support: support@tekraqual.com</li>
      </ul>
    </div>
  );
};

export default ContactPage;
