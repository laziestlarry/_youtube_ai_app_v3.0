#!/bin/bash
echo "🚀 AutonomaX Mega Pack Launcher"
echo "--------------------------------"
echo "Select an option to open:"
echo "1) AutonomaX_Creator_Kit_v1"
echo "2) Fiverr_Starter_Kit_v1"
echo "3) Shopify_Creator_Kit_v1"
echo "4) AI_Command_Center"
echo "5) AutonomaX_Canvas_v1_7"
echo "6) Commander_Brain_Pack"
echo "7) Exit"
read -p "Enter choice [1-7]: " choice

case $choice in
  1) unzip -o AutonomaX_Creator_Kit_v1.zip -d ./AutonomaX_Creator_Kit_v1 ;;
  2) unzip -o Fiverr_Starter_Kit_v1.zip -d ./Fiverr_Starter_Kit_v1 ;;
  3) unzip -o Shopify_Creator_Kit_v1.zip -d ./Shopify_Creator_Kit_v1 ;;
  4) unzip -o AI_Command_Center.zip -d ./AI_Command_Center ;;
  5) unzip -o autonomax_canvas_v1_7.zip -d ./autonomax_canvas_v1_7 ;;
  6) unzip -o Commander_Brain_Pack.zip -d ./Commander_Brain_Pack ;;
  7) echo "Exiting..." ; exit 0 ;;
  *) echo "Invalid choice" ;;
esac
