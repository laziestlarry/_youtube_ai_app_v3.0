
#!/usr/bin/env python3
import os, zipfile, argparse, sys, json, textwrap, pathlib

PACK = os.path.abspath(os.path.join(os.path.dirname(__file__), "mega_all_pack.zip"))

def list_contents():
    with zipfile.ZipFile(PACK, "r") as z:
        files = z.namelist()
    print("\n>> mega_all_pack.zip contents ({} items):".format(len(files)))
    for f in files:
        print(" -", f)

def unpack(target="kits"):
    target = os.path.abspath(target)
    os.makedirs(target, exist_ok=True)
    with zipfile.ZipFile(PACK, "r") as z:
        for name in z.namelist():
            if name.endswith((".zip", ".pdf", ".png", ".webp", ".txt", "README.md")):
                # Extract nested zips & assets into target/
                out = os.path.join(target, name)
                os.makedirs(os.path.dirname(out), exist_ok=True)
                with z.open(name) as src, open(out, "wb") as dst:
                    dst.write(src.read())
    print(f">> Unpacked primary files into: {target}")
    # Optionally unzip nested kits
    nested = [
        "AutonomaX_Creator_Kit_v1.zip",
        "Fiverr_Starter_Kit_v1.zip",
        "Shopify_Creator_Kit_v1.zip",
    ]
    for n in nested:
        p = os.path.join(target, n)
        if os.path.exists(p):
            subdir = os.path.join(target, os.path.splitext(n)[0])
            os.makedirs(subdir, exist_ok=True)
            with zipfile.ZipFile(p, "r") as z2:
                z2.extractall(subdir)
            print(f">> Expanded {n} -> {subdir}")
    print(">> Done.")

def main():
    ap = argparse.ArgumentParser(description="AutonomaX Mega Pack Launcher")
    ap.add_argument("--list", action="store_true", help="List contents of the pack")
    ap.add_argument("--unpack", nargs="?", const="kits", help="Unpack all files into target directory (default: kits)")
    args = ap.parse_args()
    if args.list:
        list_contents()
    elif args.unpack is not None:
        unpack(args.unpack)
    else:
        ap.print_help()

if __name__ == "__main__":
    main()
