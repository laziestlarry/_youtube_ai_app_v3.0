
#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
python3 "$DIR/launch.py" --unpack kits
python3 "$DIR/launch.py" --list
echo ""
echo "Next: explore ./kits/AutonomaX_Creator_Kit_v1, ./kits/Fiverr_Starter_Kit_v1, ./kits/Shopify_Creator_Kit_v1"
